<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreFacilitieRequest;
use App\Http\Requests\UpdateFacilitieRequest;
use App\Models\Facilitie;

class FacilitieController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreFacilitieRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Facilitie $facilitie)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Facilitie $facilitie)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateFacilitieRequest $request, Facilitie $facilitie)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Facilitie $facilitie)
    {
        //
    }
}
